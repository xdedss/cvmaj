


# 把unlabeled挪到labeled，同时复制一份到labeled中响应标签文件夹中

import os
import cv2
import random
import numpy as np

def mse(imageA, imageB):
    # the 'Mean Squared Error' between the two images is the
    # sum of the squared difference between the two images;
    # NOTE: the two images must have the same dimension
    err = np.sum((imageA.astype("float") - imageB.astype("float")) ** 2)
    err /= float(imageA.shape[0] * imageA.shape[1])
    return err

def tryPredict(img, sampleCount = 3):
    predResult = []
    for label in os.listdir('labeled/label/'):
        sampleList = [n for n in os.listdir('labeled/label/' + label)]
        if (len(sampleList) == 0):
            # no sample, give up
            continue
        samples = random.sample(sampleList, min(sampleCount, len(sampleList)))
        # read samples
        samplesImg = [cv2.imread('labeled/label/%s/%s' % (label, sample)) for sample in samples]
        meanErr = 0
        for sampleImg in samplesImg:
            # mse
            err = mse(img, cv2.resize(sampleImg, (img.shape[1], img.shape[0])))
            meanErr += err
        meanErr /= sampleCount
        # append result
        predResult.append([label, meanErr])
    # sort by error
    predResult.sort(key=lambda i:i[1])
    if (len(predResult) < 2):
        return None
    return [predResult[0], predResult[1]]


if (not os.path.isdir('labeled/label/')):
    os.makedirs('labeled/label/')
# big
path = 'unlabeled/big/'
pathTo = 'labeled/big/'
pathLabel = 'labeled/label/%s/'
for fname in os.listdir(path):
    fullPath = path + fname
    fullPathTo = pathTo + fname
    
    img = cv2.imread(fullPath)
    cv2.imshow('preview', img)
    cv2.waitKey(10)
    # try predict here
    predictions = tryPredict(img, 10)
    print('---------------')
    print(predictions)
    pred, err = predictions[0]
    pred1, err1 = predictions[1]
    if (err < 400 and (err1 / (err+1) > 2)):
        # very certain
        print('skip')
        labelName = pred
    elif (err < 1000):
        # maybe
        labelName = input()
        if (labelName == ''):
            # default
            labelName = pred
    else:
        # need manual input
        labelName = ''
        while (labelName == ''):
            print('MANUAL INPUT')
            labelName = input()
    
    pathLabel_ = (pathLabel % labelName)
    if (not os.path.isdir(pathLabel_)):
        os.makedirs(pathLabel_)
    fullPathCopy = pathLabel_ + fname
    cv2.imwrite(fullPathCopy, img)
    os.rename(fullPath, fullPathTo)


